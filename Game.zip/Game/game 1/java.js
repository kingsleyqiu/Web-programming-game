let boardheight = window.innerHeight;
let boardwidth = window.innerWidth;

let charwidth = 80;
let charheight = 56;
let begin_postx = 200;
let begin_posty = boardheight - charheight; 

let charimg;

let char = {
    x: begin_postx,
    y: 500,
    width: charwidth,
    height: charheight
}

// starting block
let blockwidth = 1612;
let blockheight = 264;
let blockX = 0;
let blockY = boardheight - blockheight;
let blockimg;

let block = {
    width: blockwidth,
    height: blockheight,
    x: blockX,
    y: blockY
}

// obstacles part
let obsArr = [];

let obsheight1 = 64;
let obswidth1 = 160;

let obsheight2 = 76;
let obswidth2 = 188;

let obsheight3 = 100;
let obswidth3 = 268;

let obsheight4 = 116;
let obswidth4 = 328;

let obsheight5 = 72;
let obswidth5 = 224;

let obsheight6 = 72;
let obswidth6 = 280;

let obsheight7 = 88;
let obswidth7 = 372;

let obs_spawnx = window.innerWidth + 20;
let obs_spawny1 = boardheight - obsheight1;
let obs_spawny2 = boardheight - obsheight2;

let obsImg; 
let obsImg2; 
let obsImg3; 
let obsImg4; 
let obsImg5; 
let obsImg6; 
let obsImg7; 

// game physics
let velocityX = -5;
let velocityY = 0;
let gravity = 0.3;
let dead = false;
let score = 0;
let timer = 0; 

// Increase score every 10ms
function increaseScore() {
    if (!dead) {
        score++;
    }
}


window.onload = function () {
    let board = document.getElementById("board");
    board.height = boardheight;
    board.width = boardwidth; 

    random = board.getContext("2d");

    charimg = new Image();
    charimg.src = "./char_img/jellosprite.gif";

    charimg.onload = function () {
        random.drawImage(charimg, char.x, char.y, char.width, char.height);
    }

    blockimg = new Image();
    blockimg.src = "./char_img/startingplat.png";

    //create platforms img objects
    obsImg = new Image();
    obsImg.src = "./char_img/plat1.png";

    obsImg2 = new Image();
    obsImg2.src = "./char_img/plat2.png";

    obsImg3 = new Image();
    obsImg3.src = "./char_img/plat3.png";

    obsImg4 = new Image();
    obsImg4.src = "./char_img/plat4.png";

    obsImg5 = new Image();
    obsImg5.src = "./char_img/bridge1.png";

    obsImg6 = new Image();
    obsImg6.src = "./char_img/bridge1.png";

    obsImg7 = new Image();
    obsImg7.src = "./char_img/bridge1.png";

    requestAnimationFrame(update);
    setInterval(placeobs, 700);

    // Start increasing score
    setInterval(increaseScore, 10);

    document.addEventListener("keydown", charmove);
}

function update() {
    requestAnimationFrame(update);

    if (dead) {
        return;
    }

    random.clearRect(0, 0, boardwidth, boardheight);

    velocityY += gravity;
    char.y = Math.min(char.y + velocityY, begin_posty);

    //checks if the character touches the bottom or the left edge of the screen aka the canvas
    if (char.y === begin_posty || char.x === 0) {
        dead = true;
        charimg.src = "./char_img/jellodead.png";
        charimg.onload = function () {
            random.drawImage(charimg, char.x, char.y, char.width, char.height);
        }
        showGameOverWindow();
    }

    random.drawImage(charimg, char.x, char.y, char.width, char.height);

    //loops the obsticles array
    for (let i = 0; i < obsArr.length; i++) {
        let obs = obsArr[i];
        obs.x += velocityX;
        random.drawImage(obs.img, obs.x, obs.y, obs.width, obs.height);

        if (detectcollision(char, obs)) {
            if (detectside(char, obs)) {
                char.x -= 10;
                velocityY += gravity;
            } else {
                char.y = obs.y - char.height;
                velocityY = 0;
                charimg.src = "./char_img/jellosprite.gif";
                charimg.onload = function () {
                    random.drawImage(charimg, char.x, char.y, char.width, char.height);
                }
            }
        }
    }

    //starting block movement
    block.x += velocityX;
    random.drawImage(blockimg, block.x, block.y, block.width, block.height);

    if (detectcollision(char, block)) {
        char.y = block.y - char.height;
        velocityY = 0;
        charimg.src = "./char_img/jellosprite.gif";
        charimg.onload = function () {
            random.drawImage(charimg, char.x, char.y, char.width, char.height);
        }
    }
}

//basically dected if user pressed w or space n jump
function charmove(e) {
    if (dead) {
        return;
    }
    if ((e.code === "Space" || e.key === "w") && velocityY === 0) {
        velocityY = -15;
        charimg.src = "./char_img/jellojumpsprite.png";
        charimg.onload = function () {
            random.drawImage(charimg, char.x, char.y, char.width, char.height);
        }
    }
}

//it just spawns platforms
function placeobs() {
    let obs = {
        img : null,
        x : obs_spawnx,
        y : null,
        width : null,
        height : null
    }

    let obschance = Math.random();

    if (obschance >= 0.84) {
        obs.img = obsImg;
        obs.width = obswidth1;
        obs.height = obsheight1;
        obs.y = boardheight - getRandomNumber(obsheight1+100, boardheight-(charheight+200));;
        obsArr.push(obs);
    }
    else if (obschance < 0.84 && obschance >= 0.7) {
        obs.img = obsImg2;
        obs.width = obswidth2;
        obs.height = obsheight2;
        obs.y = boardheight - getRandomNumber(obsheight2+100, boardheight-(charheight+200));;
        obsArr.push(obs);
    }
    else if (obschance < 0.7 && obschance >= 0.56){
        obs.img = obsImg3;
        obs.width = obswidth3;
        obs.height = obsheight3;
        obs.y = boardheight - getRandomNumber(obsheight3+100, boardheight-(charheight+200));;
        obsArr.push(obs);
    }
    else if (obschance < 0.56 && obschance >= 0.42){
        obs.img = obsImg4;
        obs.width = obswidth4;
        obs.height = obsheight4;
        obs.y = boardheight - getRandomNumber(obsheight4+100, boardheight-(charheight+200));;
        obsArr.push(obs);
    }
    else if (obschance < 0.42 && obschance >= 0.28){
        obs.img = obsImg5;
        obs.width = obswidth5;
        obs.height = obsheight5;
        obs.y = boardheight - getRandomNumber(obsheight5+100, boardheight-(charheight+200));;
        obsArr.push(obs);
    }
    else if (obschance < 0.28 && obschance >= 0.14){
        obs.img = obsImg6;
        obs.width = obswidth6;
        obs.height = obsheight6;
        obs.y = boardheight - getRandomNumber(obsheight6+100, boardheight-(charheight+200));;
        obsArr.push(obs);
    }
    else {
        obs.img = obsImg7;
        obs.width = obswidth7;
        obs.height = obsheight7;
        obs.y = boardheight - getRandomNumber(obsheight7+100, boardheight-(charheight+200));;
        obsArr.push(obs);
    }

    if (obsArr.length > 10) {
        obsArr.shift();
    }
}

//generates a random number 
function getRandomNumber(min, max) {
    return Math.random() * (max - min) + min;
}

//does what the function says
function detectcollision(a, b) {
    return a.x < b.x + b.width &&
        a.x + a.width > b.x &&
        a.y < b.y + b.height &&
        a.y + a.height > b.y;
}

//checks if the side of the platfrom is touching the character
function detectside(a, b) {
    return a.y + a.height > b.y &&
        a.x + a.width > b.x &&
        a.x < b.x &&
        a.y < b.y + b.height;
}

// Show Game Over window and submit score
function showGameOverWindow() {
    alert(`Game Over! Your Score: ${score}`);
    let submitWindow = window.open("", "Submit Score", "width=400,height=300");

    submitWindow.document.write(`
        <h2>Submit Your Score</h2>
        <form onsubmit="event.preventDefault(); submitScore();">
            <label for="username">Name (3 letters):</label>
            <input type="text" id="username" maxlength="3" required>
            <br>
            <button type="submit">Submit</button>
        </form>
        <h2>Leaderboard</h2>
        <div id="leaderboard"></div>

        <script>
            function submitScore() {
                const username = document.getElementById('username').value.toUpperCase();
                if (username.length !== 3 || !/^[A-Z]+$/.test(username)) {
                    alert("Name must be exactly 3 alphabetic characters.");
                    return;
                }

                const leaderboard = JSON.parse(window.opener.localStorage.getItem("leaderboard")) || [];
                leaderboard.push({ username: username, score: ${score} });

                // Sort by score
                leaderboard.sort((a, b) => b.score - a.score);
                if (leaderboard.length > 5) {
                    leaderboard.pop();
                }

                // Save leaderboard
                window.opener.localStorage.setItem("leaderboard", JSON.stringify(leaderboard));

                // Update leaderboard display
                displayLeaderboard();
            }

            function displayLeaderboard() {
                const leaderboard = JSON.parse(window.opener.localStorage.getItem("leaderboard")) || [];
                const leaderboardDiv = document.getElementById("leaderboard");
                leaderboardDiv.innerHTML = "<h3>Top Scores</h3>";

                leaderboard.forEach(entry => {
                    const entryElement = document.createElement("p");
                    entryElement.textContent = \`\${entry.username}: \${entry.score}\`;
                    leaderboardDiv.appendChild(entryElement);
                });
            }

            // Initialize leaderboard display
            displayLeaderboard();
        </script>
    `);

    submitWindow.document.close();
}

// Submit score to leaderboard
function submitForm() {
    const username = document.getElementById('username').value.toUpperCase();
    if (username.length !== 3 || !/^[A-Z]+$/.test(username)) {
        alert("Name must be exactly 3 alphabetic characters.");
        return;
    }

    const leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];
    leaderboard.push({ username: username, score: score });

    // Sort by score
    leaderboard.sort((a, b) => b.score - a.score);
    if (leaderboard.length > 5) {
        leaderboard.pop();
    }

    // Save leaderboard
    localStorage.setItem("leaderboard", JSON.stringify(leaderboard));

    // Reload leaderboard in the current window
    displayLeaderboard();
}

// Display leaderboard in pop-up window
function displayLeaderboard(windowObj) {
    const leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];
    const leaderboardDiv = windowObj.document.getElementById("leaderboard");
    leaderboardDiv.innerHTML = "<h2>Top Scores</h2>";

    leaderboard.forEach(entry => {
        const entryElement = windowObj.document.createElement("p");
        entryElement.textContent = `${entry.username}: ${entry.score}`;
        leaderboardDiv.appendChild(entryElement);
    });
}

